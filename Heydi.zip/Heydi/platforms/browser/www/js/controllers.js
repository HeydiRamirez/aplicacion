angular.module('starter.controllers', []) 
.controller('DashCtrl', function($scope) {})
.controller('LoginCtrl', function($scope) {})
.controller('RegistrateCtrl', function($scope) {})
.controller('DesarrolladorCtrl', function($scope) {})
.controller('FacebookCtrl', function($scope) {})
.controller('TwitterCtrl', function($scope) {})
.controller('WhatsappCtrl', function($scope) {})
.controller('CameraCtrl', function($scope) {})
.controller('DashMusicaCtrl', function($scope) {})
.controller('DashMusicaAdeleCtrl', function($scope) {})
.controller('DashMusicaJamesCtrl', function($scope) {})
.controller('DashMusicaMarcCtrl', function($scope) {})
.controller('DashMusicaEnriqueCtrl', function($scope) {})
.controller('DashMusicaRomeoCtrl', function($scope) {})
.controller('DashLlamadasCtrl', function($scope) {})
.controller('DashContactosCtrl', function($scope) {})
.controller('DashJuegosCtrl', function($scope) {})
.controller('DashComprasCtrl', function($scope) {})
/*.controller('DashMusicaCtrl', function($scope) {})*/
.controller('DashMicroCtrl', function($scope) {})
.controller('DashExperimentosCtrl', function($scope) {})


.controller('vibracionCtrl', function($scope) {
 $scope.experimentos1 = function() {
  alert("jjjj");
   navigator.vibrate(3000);
 }
   
})

.controller('RedesSocialesCtrl') , function($state, $scope){
  $scope.Eventofacebook= function(){
    $state.go('tab.facebook');
  }

    $scope.Eventotwitter= function(){
    $state.go('tab.twitter');
  }
    $scope.Eventowhatsapp= function(){
    $state.go('tab.whatsapp');
  }
}
.controller('reproducirCtrl', function($scope){
$scope.playAudio = function(src) {
            // Crea un objeto `Media` desde el argumento
            my_media = new Media(src, onSuccess, onError);

            // Reproduce el audio
            my_media.play();

            // Actualiza la posición cada segundo
            if (mediaTimer == null) {
                mediaTimer = setInterval(function() {
                    // Obtiene la posición actual
                    my_media.getCurrentPosition(
                        // Función 'callback' satisfactoria
                        function(position) {
                            if (position > -1) {
                                setAudioPosition((position) + " seg");
                            }
                        },
                        // Función 'callback' de error
                        function(e) {
                            console.log("Error obteniendo posición=" + e);
                            setAudioPosition("Error: " + e);
                        }
                    );
                }, 1000);
            }
        }
})
.controller('ChatsCtrl', function($scope, Chats) {
  // With the new view caching in Ionic, Controllers are only called
  // when they are recreated or on app start, instead of every page change.
  // To listen for when this page is active (for example, to refresh data),
  // listen for the $ionicView.enter event:
  //
  //$scope.$on('$ionicView.enter', function(e) {
  //});

  $scope.chats = Chats.all();
  $scope.remove = function(chat) {
    Chats.remove(chat);
  };
})

.controller('ChatDetailCtrl', function($scope, $stateParams, Chats) {
  $scope.chat = Chats.get($stateParams.chatId);
})

.controller('AccountCtrl', function($scope) {
  $scope.settings = {
    enableFriends: true
  };
})



