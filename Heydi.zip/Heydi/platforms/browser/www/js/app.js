// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.services' is found in services.js
// 'starter.controllers' is found in controllers.js
angular.module('starter', ['ionic', 'starter.controllers', 'starter.services'])

.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);

    }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }
  });
})

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider

  // setup an abstract state for the tabs directive
    .state('tab', {
    url: '/tab',
    abstract: true,
    templateUrl: 'templates/tabs.html'
  })


///TAB2 --> tabs2

//$stateProvider

  // setup an abstract state for the tabs directive
    .state('tab2', {
    url: '/tab2',
    abstract: true,
    templateUrl: 'templates/tabs2.html'
  })

//Comenzar con un login
.state('tab2.login', {
    url: '/login',
    views: {
      'tab-login': {
        templateUrl: 'templates/tab-login.html',
        controller: 'LoginCtrl'
      }
    }
  })
.state('tab2.registrate', {
    url: '/registrate',
    views: {
      'tab-login': {
        templateUrl: 'templates/tab-registrate.html',
        controller: 'RegistrateCtrl'
      }
    }
  })
  
  .state('tab2.desarrollador', {
    url: '/desarrollador',
    views: {
      'tab-login': {
        templateUrl: 'templates/tab-desarrollador.html',
        controller: 'DesarrolladorCtrl'
      }
    }
  })

   .state('tab2.facebook', {
    url: '/facebook',
    views: {
      'tab-dash': {
        templateUrl: 'templates/tab-facebook.html',
        controller: 'RedesSocialesCtrl'
      }
    }
  })

   .state('tab2.twitter', {
    url: '/twitter',
    views: {
      'tab-dash': {
        templateUrl: 'templates/tab-twitter.html',
        controller: 'RedesSocialesCtrl'
      }
    }
  })

    .state('tab2.whatsapp', {
    url: '/whatsapp',
    views: {
      'tab-dash': {
        templateUrl: 'templates/tab-whatsapp.html',
        controller: 'RedesSocialesCtrl'
      }
    }
  })
 /*.state('tab.registrate', {
    url: '/registrate',
    views: {
      'tab-registrate': {
        templateUrl: 'templates/tab-registrate.html',
        controller: 'RegistrateCtrl'
      }
    }
  })*/

  // Each tab has its own nav history stack:

  .state('tab.dash', {
    url: '/dash',
    views: {
      'tab-dash': {
        templateUrl: 'templates/tab-dash.html',
        controller: 'DashCtrl'
      }
    }
  })
  /*
    .state('tab.dash-camera', {
    url: '/dash-camera',
    views: {
      'tab-dash': {
        templateUrl: 'templates/tab-camera.html',
        controller: 'DashCameraCtrl'
      }
    }
  })
*/
   .state('tab.camera', {
    url: '/camera',
    views: {
      'tab-dash': {
        templateUrl: 'templates/tab-camera.html',
        controller: 'CameraCtrl'
      }
    }
  })

   .state('tab.llamadas', {
    url: '/llamadas',
    views: {
      'tab-dash': {
        templateUrl: 'templates/tab-llamadas.html',
        controller: 'DashLlamadasCtrl'
      }
    }
  })

   .state('tab.micro', {
    url: '/mic',
    views: {
      'tab-dash': {
        templateUrl: 'templates/tab-micro.html',
        controller: 'DashMicroCtrl'
      }
    }
  })

    .state('tab.amigos', {
    url: '/amigos',
    views: {
      'tab-dash': {
        templateUrl: 'templates/tab-amigos.html',
        controller: 'DashContactosCtrl'
      }
    }
  })

     .state('tab.compras', {
    url: '/compras',
    views: {
      'tab-dash': {
        templateUrl: 'templates/tab-compras.html',
        controller: 'DashComprasCtrl'
      }
    }
  })
  
  .state('tab.experimentos', {
    url: '/experimentos',
    views: {
      'tab-dash': {
        templateUrl: 'templates/tab-experimentos.html',
        controller: 'DashExperimentosCtrl'
      }
    }
  })

  .state('tab.juegos', {
    url: '/juegos',
    views: {
      'tab-dash': {
        templateUrl: 'templates/tab-juegos.html',
        controller: 'DashJuegosCtrl'
      }
    }
  })

  .state('tab.musica', {
    url: '/musica',
    views: {
      'tab-dash': {
        templateUrl: 'templates/tab-musica.html',
        controller: 'DashMusicaCtrl'
      }
    }
  })

    .state('tab.musicaAdele', {
    url: '/musicaAdele',
    views: {
      'tab-dash': {
        templateUrl: 'templates/tab-musicaAdele.html',
        controller: 'DashMusicaAdeleCtrl'
      }
    }
  })

   .state('tab.musicaJames', {
    url: '/musicaJames',
    views: {
      'tab-dash': {
        templateUrl: 'templates/tab-musicaJames.html',
        controller: 'DashMusicaJamesCtrl'
      }
    }
  })


    .state('tab.musicaMarc', {
    url: '/musicaMarc',
    views: {
      'tab-dash': {
        templateUrl: 'templates/tab-musicaMarc.html',
        controller: 'DashMusicaMarcCtrl'
      }
    }
  })

   .state('tab.musicaEnrique', {
    url: '/musicaEnrique',
    views: {
      'tab-dash': {
        templateUrl: 'templates/tab-musicaEnrique.html',
        controller: 'DashMusicaEnriqueCtrl'
      }
    }
  })

    .state('tab.musicaRomeo', {
    url: '/musicaRomeo',
    views: {
      'tab-dash': {
        templateUrl: 'templates/tab-musicaRomeo.html',
        controller: 'DashMusicaRomeoCtrl'
      }
    }
  })
  .state('tab.chats', {
      url: '/chats',
      views: {
        'tab-chats': {
          templateUrl: 'templates/tab-chats.html',
          controller: 'ChatsCtrl'
        }
      }
    })
    .state('tab.chat-detail', {
      url: '/chats/:chatId',
      views: {
        'tab-chats': {
          templateUrl: 'templates/chat-detail.html',
          controller: 'ChatDetailCtrl'
        }
      }
    })

  .state('tab.account', {
    url: '/account',
    views: {
      'tab-account': {
        templateUrl: 'templates/tab-account.html',
        controller: 'AccountCtrl'
      }
    }
  })




  // if none of the above states are matched, use this as the fallback
  //
 // $urlRouterProvider.otherwise('/tab/dash');
 $urlRouterProvider.otherwise('/tab2/login');

});
